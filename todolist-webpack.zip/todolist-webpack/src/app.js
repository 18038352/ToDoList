const express = require('express');
const app = express();
const path = require('path');
const port = 3243;
const Lists = require('./mongodb') // Import the Task model
//const bodyParser = require("body-parser")



//middleware and static files
app.use(express.urlencoded({extended:false}))//get mongodbdata
app.use(express.json()); // Middleware to parse JSON data in requests
const templatePath = path.join(__dirname, '../templates'); //hbs file
app.use(express.static(path.join(__dirname, '../public'))); //css and js
//app.use(bodyParser.json())


//register view engine
app.set('view engine', 'hbs'); //view hbs file
app.set('views', templatePath); //implement css and js


app.get('/', async (req, res) =>{
    
    Lists.find()
    .then(result => {
        res.render("todolist", { tasks: result } )
        console.log(result)
    })

})


app.post("/", async (req, res) => {
    const data = new Lists({
        title: req.body.title, //access "name=title" in hbs file
        description: req.body.description,
        date: req.body.date,
        category: req.body.category,
        priority: req.body.priority,
    })
    data.save()
    .then(result =>{
        res.redirect("/")
    })
   

})



app.delete("/:id", async (req, res) => {
    try {
      const taskId = ({ _id: req.params.id})
  
      // Delete the task from the database
      await Lists.findByIdAndDelete(taskId);
  
      res.json({ message: "Task deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Error deleting task" });
    }
});


app.listen(port, () =>{
    console.log(`server is running on port ${port}`)
})



