const mongoose = require("mongoose")

mongoose.connect('mongodb://127.0.0.1:27017/todolist')
  .then(() => {
    console.log('mongoose connected');
  })
  .catch((e) => {
    console.log('failed');
  })

  const ToDoSchema = new mongoose.Schema({ //You create a Mongoose schema using mongoose.Schema. This schema defines the structure of documents that will be stored in the "login" collection. It includes fields for "name," "email," and "password," each with its own data type and required flag.
    title: { //this way adds furthesr validation
      type: String,
      required: true
    },

    description: { //this way adds further validation
      type: String,
      required: true
    },
    
    date: String,
    category: String,
    priority: String,

})


const Lists = new mongoose.model("Tasks", ToDoSchema)

module.exports = Lists