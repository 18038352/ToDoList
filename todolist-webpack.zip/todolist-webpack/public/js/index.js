

let ulHome = document.querySelector("#Home")
let ulWork = document.querySelector("#Work")
let ulSchool = document.querySelector("#School")
let ulGrocery = document.querySelector("#Grocery")
let ulPayments = document.querySelector("#Payments")
let ulOtherHouseholdTasks = document.querySelector("#Other-Household-Tasks")
let arr = [] //add tasks here, whcih will then be printed in screen

class todolist{

    constructor(title, description, category, date, priority){
        this.title = title
        this.description = description
        this.category = category
        this.date = date
        this.priority = priority
    }

    static renderTask()
    {
        const taskItem = document.createElement("li");
        taskItem.innerHTML = ""

        arr.forEach((task, index) => {
            console.log(task.category)
            console.log(task.arr)
            
            
            taskItem.innerHTML = `<span> Title: ${task.title} - Description: ${task.description} - Date: ${task.date} - Priority: ${task.priority}</span>
            <button class="delete-button" data-index="${index}">Delete</button>`;
            
            
            switch (task.category) {
                case "Home":
                    ulHome.appendChild(taskItem);
                    break;
                case "Work":
                    ulWork.appendChild(taskItem);
                    break;
                case "School":
                    ulSchool.appendChild(taskItem);
                    break;
                case "Grocery":
                    ulGrocery.appendChild(taskItem);
                    break;
                case "Payments":
                    ulPayments.appendChild(taskItem);
                    break;
                case "Other-Household-Tasks":
                    ulOtherHouseholdTasks.appendChild(taskItem);
                    break;
                default:
                    break;
            }
        });
    }

    static addTask(tasks){
        arr.push(tasks)
        console.log(arr)
    }

}

//add button eventlistener
let addTaskBtn = document.querySelector("#addTask")
addTaskBtn.addEventListener("click", () =>{
    let titleData = document.querySelector("#title").value
    let descriptionData = document.querySelector("#description").value
    let categoryData = document.querySelector("#task-category").value
    let dateData = document.querySelector("#dueDate").value
    let priorityData = document.querySelector("#priority").value

    let newTask = new todolist(titleData, descriptionData, categoryData, dateData, priorityData)
    todolist.addTask(newTask)
    
    //clears fields
    document.querySelector("#title").value = ''
    document.querySelector("#description").value = ''
    document.querySelector("#dueDate").value = ''
    todolist.renderTask()
})



const deleteBtn = document.querySelectorAll(".delete-button")



deleteBtn.forEach((btn, i) => {
    btn.addEventListener("click", async () => {
      const taskId = btn.getAttribute("data-id");
  
      // Send a DELETE request to the server
      try {
        const response = await fetch(`/${taskId}`, {
          method: "DELETE",
        });
  
        if (response.ok) {
          // Remove the task from the screen
          const listItem = btn.closest("li");
          listItem.remove();
        } else {
          console.error("Failed to delete task");
        }
      } catch (error) {
        console.error("Error deleting task", error);
      }
    });
  });
